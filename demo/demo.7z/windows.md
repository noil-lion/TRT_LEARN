# Windows上运行深度模型推理

## 目标
1. iBotServer在Windows运行
1. 代码要兼容Linux，iBotServer能在Linux执行

## 当前情况
* iBotServer只能在Linux执行
* iBotServer当前模型是pytorch(TorchScript格式)，验证其对于TensorRT模型是否有进一步性能优化。

## 验证情况
目标：性能，质量(精度)

1. [Linux模型测试](TensorRT_Linux%E6%80%A7%E8%83%BD%E9%AA%8C%E8%AF%81.md)  
1. Windows模型测试: 待验证

## 设计
### 总体
> TensorRT是nvidia公司针对nvidia显卡训练的模型在特定平台进行加速的推理优化库，支持多维数据的推理，是一个c++库，仅支持推理，不支持训练。

![var](./pic/plan.png)

### 基本流程
1. 构造阶段（模型定义和优化）   
    * 创建网络定义。  
    * 指定构建器的配置。  
    * 调用构建器来创建引擎。
1. 运行时阶段（推理）
    * 反序列化构造好的引擎的.plan。  
    * 从引擎创建执行上下文。  
    * 填充输入缓冲区以进行推理。  
    * 调用enqueue()或者execute()在执行上下文上运行推理。

![var](./pic/enginbuild.png)

### TensorRT模型转换及引擎构建
* IR 转换模型，将中间表示的模型（ONNX）转换成 TensorRT 模型，构建推理引擎。
```mermaid
flowchart LR
ONNX模型-->TensorRT模型-->推理引擎构建-->加载引擎进行推理
```
1. Pytorch导出模型ONNX格式
2. 创建builder和网络实例
3. 解析ONNX
4. 构建engine

### TensorRT推理runtime
1. 反序列化加载引擎
1. 创建cuda流
1. 执行推理

## 环境构建
### 软硬件矩阵

![var](./pic/zip_windows.png)

![var](./pic/computer_power.png)
[CUDA版本绑定硬件驱动](https://docs.nvidia.com/cuda/cuda-toolkit-release-notes/index.html)
[搜索GPU的驱动](https://www.nvidia.cn/download/index.aspx)
[硬件及算力](https://developer.nvidia.com/zh-cn/cuda-gpus#collapseOne/)
### 软硬件
* 硬件

| 项 | 内容 | 说明 |
| - | - | - |
| 操作系统 | Windows10企业版，64位 |  |
| GPU | GeForce RTX 3090 |   |

* 软件

| 项 | 内容 | 说明 |
| - | - | - |
|GPU Driver| 517.48| |
| CUDA | 11.6 |  |
| cuDNN | 8.4 |  |
| TensorRT GA build | 8.4.3.1 ||
| Cmake| 3.13||

### 环境安装

### 环境验证

## 长期优化
| 项 | 负责人 | 完成时间 | 说明 |
| - | - | - | - |
| 内存读写数据的POC | 刘航、吴梓皓 |  |  |
| iBotServer支持通讯用内存 | 刘航 |  |  |
| iBotServer支持通讯用内存-SDK配套 | 张亚炜 |  |  |

## 知识资料
* [TensorRT](http://10.70.21.10:8888/share/triton/-/tree/master/doc/TensorRT%E7%9F%A5%E8%AF%86%E5%BA%93%E5%BB%BA%E8%AE%BE)
* [CUDA](http://10.70.21.10:8888/share/cuda)

### TensorRT官方资料
* [安装](https://docs.nvidia.com/deeplearning/tensorrt/install-guide/index.html)
* [onnx转tensorrt engine](https://docs.nvidia.com/deeplearning/tensorrt/quick-start-guide/index.html#convert-onnx-engine)
* [c++推理tensorrt engine](https://docs.nvidia.com/deeplearning/tensorrt/quick-start-guide/index.html#run-engine-c)
